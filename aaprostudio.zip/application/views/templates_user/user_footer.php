<footer class="footer is-small hero is-black">
    <div class="content has-text-centered">
        &copy; Copyright 2021 | built By.
        <a href="">
            SabangTech
        </a>
    </div>
</footer>

</html>